/**
 * Created by krzys on 04.11.2017.
 */
public class P04 {
    public static void main(String[] args) {
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 2; j++) {
//                if(i == 1){
//                    continue;
//                }
//                System.out.println(i + " " + j);
//            }
//        }


        int x = 5;
//        do{
//            System.out.println("Hello world!");
//            x--;
//        }while (x > 3);

        while(x > 3){
            System.out.println("Hello world!");
            x--;
        }

    }
}

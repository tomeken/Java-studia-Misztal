/**
 * Created by krzys on 04.11.2017.
 */
public class P01 {
    public static void main(String[] args) {
        int x = 72;

        if((x % 2 == 0 && x % 3 == 0) || (x % 5 == 0)){
            System.out.println(x + " jest podzielne przez sześć");
        }

//        if(x % 2 == 0){
//            if(x % 3 == 0){
//                System.out.println(x + " jest podzielne przez sześć");
//            }
//        }

    }
}

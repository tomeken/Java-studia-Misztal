public class Operators {
    public static void main(String[] args) {
        System.out.println(1 + 2);
        System.out.println(1 - 2);
        System.out.println(1 * 2);
        System.out.println(1 / 2);
        System.out.println(1. / 2);
        System.out.println(2 % 3);
        System.out.println(5 % 3);
    }
}

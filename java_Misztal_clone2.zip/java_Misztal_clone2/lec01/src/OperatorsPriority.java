/**
 * Created by krzys on 27.10.2017.
 */
public class OperatorsPriority {
    public static void main(String[] args) {
        System.out.println(11 - 2 + 4);
        System.out.println(11 + 2 - 4);

        System.out.println(11 * 2 / 4);
        System.out.println(11 / 2 * 4);

        System.out.println(11 * 2 + 5);
        System.out.println(10 % 2 * 5 + 9);
    }
}

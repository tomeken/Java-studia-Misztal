/**
 * Created by krzys on 03.12.2017.
 */
public class Power {
    public static void main(String[] args) {
        for(int i = 0; i <= 10; ++i) {
//            System.out.println(i + " " + i * i);
            System.out.format("%.2f %4d\n",i/13., i*i);
        }
    }
}

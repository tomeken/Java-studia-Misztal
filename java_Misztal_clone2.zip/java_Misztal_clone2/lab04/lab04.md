### Zadanie 1

Napisz program, który wypisze

```
0 0
1 1
2 4
3 9
4 16
5 25
//-- itd.
```

Rozwiązanie [Power.java](https://github.com/kmisztal/java_tutorial/blob/master/lab04/src/Power.java)

### Zadanie 2

Proszę przygotować program który wykorzystując `swtich` sprawdzi czy liczba jest podzielna przez 3.

Rorwiązanie [Switch.java](https://github.com/kmisztal/java_tutorial/blob/master/lab04/src/Switch.java)

### Zadanie 3

Proszę napisać funkcję przeliczającą stopnie Celcjusza na Fahrenheita.

Rozwiązanie [FunctionIntro](https://github.com/kmisztal/java_tutorial/blob/master/lab04/src/FunctionInto.java)

### 



